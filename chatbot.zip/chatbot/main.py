from random import *
from termcolor import colored

emphasisers = ["FUCKING ", "SO ", "BLOODY ", "FUCKIN "]
pos_adjs = ["good", "amazing", "great", "nice", "beautiful", "delightful", "delicious", "happy", "materialised"]
neg_adjs = ["bad", "terrible", "awful", "melancholy", "ugly", "disgusting", "not tasteful", "sad", "vaporized"]


class Chatter:
    def __init__(self, name, aggr, curio, intel, care, errat, happ, typo):
        self.name = name

        self.aggressiveness = aggr
        self.curiosity = curio
        self.intelligence = intel
        self.caringness = care
        self.erraticness = errat
        self.happiness = happ

        self.typo_frequency = typo

        self.msg = ""

        self.emph_chance = 0
        self.cap_chance = 0

    def process(self):
        self.emph_chance = randint(self.aggressiveness, 100)
        self.cap_chance = randint(self.aggressiveness, 100)

        if self.happiness > 50:
            self.msg = self.msg.replace("{adj}", choice(pos_adjs))
            self.msg = self.msg.replace("{sent_end}", "!" * round(self.happiness / 30))
            self.msg = self.msg.replace("{sent_end}", "")
        else:
            self.msg = self.msg.replace("{adj}", choice(neg_adjs))

        if self.emph_chance == 100:
            self.msg = self.msg.replace("{emph}", choice(emphasisers))
            self.msg = self.msg.replace("{sent_end}", "!" * round(self.aggressiveness / 90))
        else:
            self.msg = self.msg.replace("{emph}", "")
            self.msg = self.msg.replace("{sent_end}", "")

        if self.cap_chance == 100:
            self.msg = self.msg.upper()

    def say(self, msg):
        self.msg = msg

        self.process()

        print(f"{colored(f'{self.name}:', 'red')} {self.msg}")


bot = Chatter("Darcy", 1, 1, 1, 1, 1, 100, 1)

bot.say("{emph}hello{sent_end}")

while True:
    text = str(input())

    if "how" and "you" in text:
        bot.say("i am {emph}{adj}{sent_end}")
